'use client'

import { motion } from 'framer-motion'
import { Github, Linkedin, Mail, Gamepad2, Instagram } from 'lucide-react'
import useSectionInView from '../hooks/useSectionInView'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../app/components/ui/card"
import { Avatar, AvatarImage, AvatarFallback } from '../app/components/ui/avatar'
import { Separator } from '../app/components/ui/separator'
import WobbleCard from '../components/WobbleCard'

export default function Contact() {
  const { ref } = useSectionInView("Contact", 0.3);
  const email = 'partheshpurohit23@gmail.com';

  const socialLinks = [
    { icon: Mail, href: `mailto:${email}`, label: email },
    { icon: Instagram, href: 'https://www.instagram.com/parthesh28/', label: '@parthesh28' },
    { icon: Github, href: 'https://github.com/Parthesh28', label: 'Parthesh28' },
    { icon: Gamepad2, href: 'https://discordapp.com/users/764456744755003443', label: '@parthesh28' },
    { icon: Linkedin, href: 'https://www.linkedin.com/company/partheshpurohit', label: 'Parthesh Purohit' }
  ];

  return (
    <section
      id="contact"
      className="py-20"
      ref={ref}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <motion.div
          className="max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <WobbleCard>
            <Card className="w-full border shadow-md bg-zinc-100 dark:bg-zinc-900 ">
              <CardHeader className="space-y-1">
                <CardTitle className="flex items-center text-2xl">
                  <Avatar>
                    <AvatarImage src='/placeholder' />
                    <AvatarFallback>PP</AvatarFallback>
                  </Avatar>
                  Connect with Me!</CardTitle>
                <CardDescription className="text-muted-foreground">
                  Reach out to me through:
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                {socialLinks.map((link, index) => (
                  <div key={index}>
                    <div className="flex items-center group">
                      <link.icon className="w-5 h-5 mr-3 text-primary transition-colors" />
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-slate-700 dark:hover:text-slate-300"
                      >
                        {link.label}
                      </a>
                    </div>
                    {index < socialLinks.length - 1 && (
                      <Separator className="my-3" />
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </WobbleCard>
        </motion.div>
      </div>
    </section>
  );
}