'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import useSectionInView from '../hooks/useSectionInView'
import { Card, CardContent } from "../app/components/ui/card"
import { Badge } from '../app/components/ui/badge'
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "../app/components/ui/carousel"
import { Button } from "../app/components/ui/button"
import { ExternalLink } from 'lucide-react'

const projects = [
  {
    title: 'BlockMart',
    description: 'A full-featured e-commerce platform built on solidity and Ethereum blockchain.',
    image: '/placeholder.svg?height=200&width=300',
    link: '#',
    techstack: ['Solidity', 'Ethereum', 'Next.js']
  },
  {
    title: 'Pulp',
    description: 'A easy to use code-sharing platform utility for students',
    image: '/placeholder.svg?height=200&width=300',
    link: '#',
    techstack: ['Next.js', 'Cloudflare D1']
  },
  {
    title: 'CodeX',
    description: 'A fully responsive website designed for CodeX-SFIT',
    image: '/placeholder.svg?height=200&width=300',
    link: '#',
    techstack: ['Next.js']
  }
]
export default function Projects() {
  const { ref } = useSectionInView("Projects", 0.3);

  return (
    <section id="projects" className="py-20"
      ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white sm:text-4xl text-center mb-12">
            My Projects
          </h2>
        </motion.div>
        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full max-w-2xl mx-auto"
        >
          <CarouselContent>
            {projects.map((project, index) => (
              <CarouselItem key={project.title}>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                >
                  <Card className="overflow-hidden bg-zinc-100 dark:bg-zinc-900 shadow-lg">
                    <CardContent>
                      <Image
                        src={project.image}
                        alt={project.title}
                        width={300}
                        height={200}
                        className="h-44 object-cover"
                      />
                      <div className="p-6">
                        <h3 className="text-xl font-semibold text-zinc-800 dark:text-zinc-100 mb-2">{project.title}</h3>
                        <div className="flex flex-wrap gap-2 mb-4">
                          {project.techstack.map((tech, i) => (
                            <Badge key={i} variant="secondary" className="rounded-full bg-zinc-200 dark:bg-zinc-700">
                              {tech}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-zinc-600 dark:text-zinc-300 mb-4">{project.description}</p>
                        <Button asChild variant="default">
                          <a
                            href={project.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center"
                          >
                            View Project
                            <ExternalLink className="ml-2 h-4 w-4" />
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious />
          <CarouselNext />
        </Carousel>
      </div>
    </section>
  )
}




