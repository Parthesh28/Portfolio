import { useState, useEffect } from 'react';


export default function useLanyardStatus() {
    const [status, setStatus] = useState('offline');

    useEffect(() => {
        const fetchStatus = async () => {
            try {
                const response = await fetch('https://api.lanyard.rest/v1/users/764456744755003443');
                const data = await response.json();
                setStatus(data.data.discord_status);
            } catch (error) {
                console.error('Error fetching Lanyard status:', error);
            }
        };

        fetchStatus();
        const interval = setInterval(fetchStatus, 60000); // Update every minute

        return () => clearInterval(interval);
    }, []);

    return status;
}
